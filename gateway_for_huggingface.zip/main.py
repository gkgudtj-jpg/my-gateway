"""بوابة ذكاء اصطناعي خاصة بك (ملف واحد). كل الإعدادات من متغيرات البيئة."""
import sys, os, time, hashlib, secrets, sqlite3
from collections import defaultdict, deque
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
load_dotenv()
def _list(name):
    return [x.strip() for x in os.getenv(name, "").replace("\n", ",").split(",") if x.strip()]
APP_NAME = os.getenv("APP_NAME", "My AI")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")
DATABASE_PATH = os.getenv("DATABASE_PATH", "/tmp/app.db")
BACKENDS = [b.lower() for b in _list("BACKENDS")] or [os.getenv("MODEL_BACKEND", "demo").lower()]
MODEL_BACKEND = BACKENDS[0]
MODEL_ID = os.getenv("MODEL_ID", "")
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "8192"))
GEMINI_KEYS = _list("GEMINI_KEYS")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
OPENAI_URL = os.getenv("OPENAI_COMPAT_URL", "").rstrip("/")
OPENAI_KEY = os.getenv("OPENAI_COMPAT_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_COMPAT_MODEL", "")
CORS_ORIGINS = _list("CORS_ORIGINS") or ["*"]
RATE_LIMIT = int(os.getenv("RATE_LIMIT_PER_MIN", "30"))
TIMEOUT = float(os.getenv("REQUEST_TIMEOUT", "180"))
STATIC_KEYS = _list("MY_API_KEYS")

C = sys.modules[__name__]   # لتبقى مراجع C.X في الكود تعمل


def new_api_key():
    return "mai_" + secrets.token_urlsafe(32)
def digest_key(raw):
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
def safe_equal(a, b):
    return secrets.compare_digest(a, b)


def connect():
    folder = os.path.dirname(DATABASE_PATH)
    if folder: os.makedirs(folder, exist_ok=True)
    con = sqlite3.connect(DATABASE_PATH)
    con.row_factory = sqlite3.Row
    return con
def init_db():
    with connect() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS api_keys (
          id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL,
          key_hash TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL,
          last_used_at INTEGER, active INTEGER NOT NULL DEFAULT 1)''')
        con.execute('''CREATE TABLE IF NOT EXISTS usage (
          id INTEGER PRIMARY KEY AUTOINCREMENT, key_id INTEGER NOT NULL,
          backend TEXT NOT NULL, tokens INTEGER NOT NULL, ts INTEGER NOT NULL)''')
def add_key(label, key_hash):
    with connect() as con:
        cur = con.execute("INSERT INTO api_keys(label,key_hash,created_at) VALUES(?,?,?)",
                          (label, key_hash, int(time.time())))
        return cur.lastrowid
def find_active_key(raw):
    with connect() as con:
        row = con.execute("SELECT id,label FROM api_keys WHERE key_hash=? AND active=1",
                          (digest_key(raw),)).fetchone()
        if row: con.execute("UPDATE api_keys SET last_used_at=? WHERE id=?", (int(time.time()), row["id"]))
        return dict(row) if row else None
def list_keys():
    with connect() as con:
        return [dict(r) for r in con.execute("SELECT id,label,created_at,last_used_at,active FROM api_keys ORDER BY id DESC")]
def revoke_key(key_id):
    with connect() as con:
        cur = con.execute("UPDATE api_keys SET active=0 WHERE id=?", (key_id,))
        return cur.rowcount > 0
def log_usage(key_id, backend, tokens):
    with connect() as con:
        con.execute("INSERT INTO usage(key_id,backend,tokens,ts) VALUES(?,?,?,?)", (key_id, backend, tokens, int(time.time())))
def usage_summary():
    with connect() as con:
        return [dict(r) for r in con.execute("SELECT key_id,backend,COUNT(*) AS requests,SUM(tokens) AS tokens_est FROM usage GROUP BY key_id,backend")]




class ProviderError(Exception):
    pass

_cool = {}   # مفتاح Gemini -> وقت انتهاء فترة الانتظار
_pipe = None

def _tail(k):
    return "…" + k[-4:]

def key_states():
    now = time.time()
    return [{"key": _tail(k), "cooldown_s": max(0, int(_cool.get(k, 0) - now))} for k in C.GEMINI_KEYS]

def gemini(messages, max_tokens, json_mode):
    if not C.GEMINI_KEYS:
        raise ProviderError("GEMINI_KEYS غير مضبوطة")
    keys = [k for k in C.GEMINI_KEYS if _cool.get(k, 0) <= time.time()]
    if not keys:
        raise ProviderError("كل مفاتيح Gemini في فترة انتظار")
    system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
    contents = [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
                for m in messages if m["role"] != "system"]
    if not contents:
        raise ProviderError("لا توجد رسالة مستخدم")
    body = {"contents": contents, "generationConfig": {"maxOutputTokens": max_tokens, "temperature": 0.6}}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    if json_mode:
        body["generationConfig"]["responseMimeType"] = "application/json"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{C.GEMINI_MODEL}:generateContent"
    errors = []
    for k in keys:
        try:
            r = httpx.post(url, headers={"x-goog-api-key": k}, json=body, timeout=C.TIMEOUT)
        except httpx.HTTPError as e:
            errors.append(f"{_tail(k)}: اتصال ({type(e).__name__})")
            continue
        if r.status_code == 429:
            _cool[k] = time.time() + 3600
            errors.append(f"{_tail(k)}: 429 حصة")
            continue
        if r.status_code in (401, 403):
            _cool[k] = time.time() + 86400
            errors.append(f"{_tail(k)}: {r.status_code} مرفوض")
            continue
        if r.status_code >= 400:   # 404 (اسم النموذج) أو 5xx: لا فائدة من تبديل المفتاح
            raise ProviderError(f"Gemini {r.status_code}: {r.text[:160]}")
        try:
            parts = r.json()["candidates"][0]["content"]["parts"]
            return "".join(p.get("text", "") for p in parts)
        except (KeyError, IndexError, ValueError):
            raise ProviderError("رد Gemini فارغ أو محجوب: " + r.text[:160])
    raise ProviderError("; ".join(errors))

def openai_compat(messages, max_tokens, json_mode):
    if not C.OPENAI_URL or not C.OPENAI_MODEL:
        raise ProviderError("OPENAI_COMPAT_URL/MODEL غير مضبوطة")
    body = {"model": C.OPENAI_MODEL, "messages": messages, "max_tokens": max_tokens}
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    headers = {"Authorization": f"Bearer {C.OPENAI_KEY}"} if C.OPENAI_KEY else {}
    try:
        r = httpx.post(C.OPENAI_URL + "/chat/completions", headers=headers, json=body, timeout=C.TIMEOUT)
    except httpx.HTTPError as e:
        raise ProviderError(f"اتصال ({type(e).__name__})")
    if r.status_code >= 400:
        raise ProviderError(f"{r.status_code}: {r.text[:160]}")
    return r.json()["choices"][0]["message"]["content"]

def transformers(messages, max_tokens, json_mode):
    global _pipe
    if not C.MODEL_ID:
        raise ProviderError("MODEL_ID غير مضبوط")
    try:
        from transformers import pipeline
    except ImportError:
        raise ProviderError("ثبّت torch وtransformers وaccelerate على خادم GPU")
    if _pipe is None:
        _pipe = pipeline("text-generation", model=C.MODEL_ID, device_map="auto")
    out = _pipe(messages, max_new_tokens=max_tokens, do_sample=True, temperature=0.7)
    return out[0]["generated_text"][-1]["content"].strip()

def demo(messages, max_tokens, json_mode):
    last = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
    return "وضع التجربة: هذا ليس نموذجًا مدرّبًا. رسالتك: " + last[:300]

ENGINES = {"gemini": gemini, "openai_compat": openai_compat, "transformers": transformers, "demo": demo}

def generate(messages, max_tokens=256, json_mode=False):
    max_tokens = max(1, min(int(max_tokens), C.MAX_TOKENS))
    errors = []
    for name in C.BACKENDS:
        fn = ENGINES.get(name)
        if not fn:
            errors.append(f"{name}: محرك غير معروف")
            continue
        try:
            return name, fn(messages, max_tokens, json_mode)
        except ProviderError as e:
            errors.append(f"{name}: {e}")
        except Exception as e:
            errors.append(f"{name}: {type(e).__name__}")
    raise ProviderError(" | ".join(errors))


from collections import defaultdict, deque
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
app = FastAPI(title=APP_NAME, version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=C.CORS_ORIGINS, allow_methods=["*"], allow_headers=["*"])
init_db()
recent = defaultdict(deque)
class Message(BaseModel):
    role: str = Field(pattern="^(system|user|assistant)$")
    content: str
class ChatRequest(BaseModel):
    model: str = "my-ai"
    messages: list[Message] = Field(min_length=1)
    max_tokens: int = Field(default=256, ge=1, le=65536)
    json_mode: bool = False
    response_format: dict | None = None
def admin(token):
    if not ADMIN_TOKEN or not token or not safe_equal(token, ADMIN_TOKEN):
        raise HTTPException(401, "مفتاح الإدارة غير صحيح")
def api_key(auth):
    if not auth or not auth.lower().startswith("bearer "):
        raise HTTPException(401, "أرسل Authorization: Bearer YOUR_API_KEY")
    raw = auth.split(" ", 1)[1].strip()
    record = find_active_key(raw)
    if not record and any(safe_equal(raw, k) for k in C.STATIC_KEYS):
        record = {"id": 0, "label": "env-key-" + raw[-4:]}
    if not record: raise HTTPException(401, "المفتاح غير صحيح أو ملغى")
    q, now = recent[record["id"] or record["label"]], time.time()
    while q and now-q[0] > 60: q.popleft()
    if len(q) >= C.RATE_LIMIT: raise HTTPException(429, f"تجاوزت حد {C.RATE_LIMIT} طلبًا في الدقيقة")
    q.append(now)
    return record
@app.get("/", response_class=HTMLResponse)
def home():
    with open("index.html", encoding="utf-8") as f: return f.read().replace("{{APP_NAME}}", APP_NAME)
@app.get("/health")
def health(): return {"status":"ok", "app":APP_NAME, "model_backend":MODEL_BACKEND}
@app.post("/admin/keys")
def create_key(payload: dict, x_admin_token: str | None = Header(default=None)):
    admin(x_admin_token)
    label = str(payload.get("label", "مشروعي"))[:80].strip() or "مشروعي"
    raw = new_api_key()
    key_id = add_key(label, digest_key(raw))
    return {"id":key_id, "label":label, "api_key":raw, "warning":"احفظ المفتاح الآن؛ لن يظهر مرة أخرى."}
@app.get("/admin/keys")
def keys(x_admin_token: str | None = Header(default=None)):
    admin(x_admin_token); return {"keys":list_keys()}
@app.delete("/admin/keys/{key_id}")
def delete_key(key_id: int, x_admin_token: str | None = Header(default=None)):
    admin(x_admin_token)
    if not revoke_key(key_id): raise HTTPException(404, "المفتاح غير موجود")
    return {"status":"revoked","id":key_id}
@app.get("/v1/models")
def models(authorization: str | None = Header(default=None)):
    api_key(authorization)
    return {"object":"list","data":[{"id":"my-ai","object":"model","owned_by":"me"}]}
@app.get("/admin/status")
def status(x_admin_token: str | None = Header(default=None)):
    admin(x_admin_token)
    return {"backends":C.BACKENDS,"gemini_model":C.GEMINI_MODEL,"gemini_keys":key_states(),"usage":usage_summary()}
@app.post("/v1/chat/completions")
def chat(payload: ChatRequest, authorization: str | None = Header(default=None)):
    record = api_key(authorization)
    msgs = [m.model_dump() for m in payload.messages]
    json_mode = payload.json_mode or (payload.response_format or {}).get("type") == "json_object"
    try: backend, answer = generate(msgs, payload.max_tokens, json_mode)
    except ProviderError as exc: raise HTTPException(503, "النموذج غير متاح: " + str(exc)[:600])
    pt, ct = sum(len(m["content"]) for m in msgs)//4, len(answer)//4
    log_usage(record["id"], backend, pt+ct)
    return {"id":f"chatcmpl-{int(time.time()*1000)}","object":"chat.completion",
            "created":int(time.time()),"model":payload.model,"backend":backend,
            "choices":[{"index":0,"message":{"role":"assistant","content":answer},"finish_reason":"stop"}],
            "usage":{"prompt_tokens":pt,"completion_tokens":ct,"total_tokens":pt+ct,"estimated":True},
            "key_label":record["label"]}
