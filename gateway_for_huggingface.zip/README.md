---
title: My AI Gateway
sdk: docker
app_port: 8000
---
بوابة ذكاء اصطناعي خاصة. الإعدادات في Settings > Secrets: ADMIN_TOKEN, GEMINI_KEYS, MY_API_KEYS.
